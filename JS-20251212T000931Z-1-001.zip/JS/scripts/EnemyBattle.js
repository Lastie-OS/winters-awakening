class EnemyBattle extends Phaser.Scene {
    constructor() {
        super('EnemyBattle');
    }

    preload() {

        this.load.image('playerSoul', 'assets/images/soul.png');
        this.load.audio('startMenu', 'assets/audio/02.mp3');
        this.load.audio('enemyApproaching', 'assets/audio/09.wav');
        this.load.audio('inferno', 'assets/audio/inferno.mp3');
    }

    create() {
        
        //  Adding plugins
        this.load.plugin('rexRoundRectangleCanvasPlugin', 'raw.githubusercontent.com', true);


        //  Adding graphics
        let graphics = this.add.graphics();


        //  Adding the [LEGALLY AQUIRED] music to the game!
        gameState.backgroundMusic = {};
        gameState.backgroundMusic[0] = this.sound.add('startMenu'); gameState.backgroundMusic[1] = this.sound.add('enemyApproaching'); gameState.backgroundMusic.infer = this.sound.add('inferno');


        //  Bullet board is the UT Battle engine/room.
        const boardX = 360;
        const boardY = 550;
        const boardW = 600;
        const boardH = 150;
        const borderThickness = 4;

        //  Save board bounds for use in update() (clamping)
        gameState.board = { x: boardX, y: boardY, w: boardW, h: boardH, border: borderThickness };


        //  Draw the battle board background
        const fillGraphics = this.add.graphics();
        fillGraphics.fillStyle(0x000000, 2);
        fillGraphics.fillRect(boardX - boardW / 2, boardY - boardH / 2, boardW, boardH);


        //  Creating a [Dark Zone] to act as the collider
        gameState.bulletBoard = this.add.zone(boardX, boardY, boardW, boardH);
        this.physics.add.existing(gameState.bulletBoard, true);


        //  Expanding the static body so it sits over the border for collision
        if (gameState.bulletBoard.body) {
            gameState.bulletBoard.body.setSize(boardW + borderThickness * 2, boardH + borderThickness * 2);
            gameState.bulletBoard.body.setOffset(-borderThickness, -borderThickness);
        }


        //  Drawing the border on top so it renders over the board
        const borderGraphics = this.add.graphics();
        borderGraphics.lineStyle(borderThickness, 0xffffff, 2);
        borderGraphics.strokeRect(boardX - boardW / 2, boardY - boardH / 2, boardW, boardH);
        borderGraphics.setDepth(20);


        //  The player's soul. The very culmination of their being.
        gameState.playerSoul = this.physics.add.sprite(boardX, boardY, 'playerSoul').setInteractive()
        gameState.playerSoul.speed = 320;
        gameState.playerSoul.displayHeight = 18; gameState.playerSoul.displayWidth = 18;


        //  Registering keys
        gameState.cursors = this.input.keyboard.createCursorKeys()
        gameState.cursors.enterKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);
        gameState.cursors.W = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
        gameState.cursors.A = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
        gameState.cursors.S = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
        gameState.cursors.Z = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.Z);
        gameState.cursors.X = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.X);
        gameState.cursors.C = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.C);
        gameState.cursors.esc = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESC);

        this.cameras.main.fadeIn(500, 0, 0, 0, false);


        //  Playing Battle Music ('Enemy Approaching')
        audioController(0, false, 'stop'); audioController(1, true, 'play');
    
    
        //  Player Health Bar
        gameState.playerHealthBar = new HealthBar(this, 20, boardY + boardH / 2 + 20, 80, 80, 80, 0xFEFF03, 0x651828, "PlayerHealthBar");
    // constructor (scene, x, y, width, health, maxHealth, healthColor = 0xFEFF03, backColor = 0x651828, name = "HealthBar") {
    }


    update() {
        // Managing playerSoul movement
        //  Managing horizontal movement (playerSoul)
        if (gameState.cursors.left.isDown) {
            gameState.playerSoul.setVelocityX(-gameState.playerSoul.speed);
        } else if (gameState.cursors.right.isDown) {
            gameState.playerSoul.setVelocityX(gameState.playerSoul.speed);
        } else {
            gameState.playerSoul.setVelocityX(0);
        }
        //  Managing vertical movement (playerSoul)
        if (gameState.cursors.down.isDown) {
            gameState.playerSoul.setVelocityY(gameState.playerSoul.speed);
        } else if (gameState.cursors.up.isDown) {
            gameState.playerSoul.setVelocityY(-gameState.playerSoul.speed);
        } else if (!gameState.cursors.up.isDown) {
            gameState.playerSoul.setVelocityY(0);
        }

        if (gameState.cursors.X.isDown) {
            gameState.playerSoul.speed = 160;
        } else {
            gameState.playerSoul.speed = 320;
        }

        //  Clamping playerSoul position to stay inside the board (prevents exiting)
        if (gameState.board && gameState.playerSoul) {
            let boardX = gameState.board.x;
            let boardY = gameState.board.y;
            let boardW = gameState.board.w;
            let boardH = gameState.board.h;

            let halfW = boardW / 2;
            let halfH = boardH / 2;

            //  If sprite origin is center, use display sizes to keep it fully inside
            let playerHalfW = gameState.playerSoul.displayWidth / 2 || 0;
            let playerHalfH = gameState.playerSoul.displayHeight / 2 || 0;

            let clampedX = Phaser.Math.Clamp(
                gameState.playerSoul.x,
                boardX - halfW + playerHalfW,
                boardX + halfW - playerHalfW
            );
            let clampedY = Phaser.Math.Clamp(
                gameState.playerSoul.y,
                boardY - halfH + playerHalfH,
                boardY + halfH - playerHalfH
            );


            // Also updates the physics body and temporarily disable gravity when clamped at the top
            const sprite = gameState.playerSoul;
            const body = sprite.body;

            if (clampedX !== sprite.x) {
                sprite.x = clampedX;
                sprite.setVelocityX(0);
                if (body) {
                    body.x = clampedX - sprite.displayWidth / 2;
                    if (body.setVelocityX) body.setVelocityX(0);
                    else body.velocity.x = 0;
                }
            }

            const topLimit = boardY - halfH + playerHalfH;
            if (clampedY !== sprite.y) {
                sprite.y = clampedY;
                sprite.setVelocityY(0);
                if (body) {
                    body.y = clampedY - sprite.displayHeight / 2;
                    if (body.setVelocityY) body.setVelocityY(0);
                    else body.velocity.y = 0;
                }
            }


            // pushed out by the global gravity between physics steps. Re-enable gravity otherwise.
            if (body) {
                if (sprite.y === topLimit) {
                    body.allowGravity = false;
                } else {
                    body.allowGravity = true;
                }
            }
        }
    }
}