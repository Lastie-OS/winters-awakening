const gameState = {
    player: {
        NAME: 'Lastie',
        LV: 1,
        EXP: 0,
        GOLD: 0,
        ITEM_EQUIPPED: 0,
        ARMOR_EQUIPPED: 0,
        STR: 5,
        DEF: 5,
        SOUL_MODE: 'RED',
        INVENTORY: [],
        MDR: 0
    },
}
