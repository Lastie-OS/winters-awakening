class TitleScene extends Phaser.Scene {
    
    constructor() {
        super('TitleScene');
    }

    

    preload() {
        this.load.audio('enemyApproaching', 'assets/audio/09.wav');
        this.load.audio('inferno', 'assets/audio/inferno.mp3');

    }

    create() {
        // Set background to black (Undertale style)
        this.cameras.main.setBackgroundColor('#000000');

        // Register Enter key early so input is ready even while font loads
        this.enterKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);

        // Function that actually creates the title text once fonts are available
        const renderTitle = () => {
            // Title text using MonsterFriend font
            this.titleText = this.add.text(
                this.scale.width / 2,
                this.scale.height / 3,
                'UNDERTALE',
                {
                    fontFamily: 'MonsterFriend',
                    fontSize: '64px',
                    color: '#ffffff',
                    align: 'center',
                    stroke: '#ffffff',
                    strokeThickness: 2
                }
            ).setOrigin(0.5, 0.5);

            // Blinking prompt text
            this.promptText = this.add.text(
                this.scale.width / 2,
                this.scale.height * 0.75,
                '* PRESS ENTER TO START',
                {
                    fontFamily: '8bitoperator',
                    fontSize: '18px',
                    color: '#ffffff',
                    align: 'center'
                }
            ).setOrigin(0.5, 0.5);

            // Create blinking animation for prompt
            this.tweens.add({
                targets: this.promptText,
                alpha: { from: 1, to: 0.3 },
                duration: 600,
                repeat: -1,
                yoyo: true
            });

            // Decorative bottom text (Undertale style flavor)
            this.flavorText = this.add.text(
                this.scale.width / 2,
                this.scale.height * 0.9,
                'An Undertale Fan Game By LastieOS!',
                {
                    fontFamily: '8bitoperator',
                    fontSize: '14px',
                    color: '#ffff00',
                    align: 'center'
                }
            ).setOrigin(0.5, 0.5);

            // Store title elements in gameState for easy reference
            gameState.titleScene = this;
        };

        // Wait for the MonsterFriend font to be loaded before rendering the title
        if (document.fonts && document.fonts.load) {
            document.fonts.load('64px "MonsterFriend"').then(() => {
                renderTitle();
            }).catch(() => {
                // If load fails, still render using available fonts
                renderTitle();
            });
        } else {
            // Older browsers: render immediately
            renderTitle();
        }
    }

    update() {
        // Check if Enter key is pressed to start the game
        if (Phaser.Input.Keyboard.JustDown(this.enterKey)) {
            // Fade out and transition to next scene
            this.cameras.main.fade(500, 0, 0, 0, false, (camera, progress) => {
                if (progress === 1) {
                    this.scene.stop('TitleScene');
                    this.scene.start('EnemyBattle'); // Replace 'GameScene' with your actual game scene name
                    
                }
            });
        }
    }

}